<?php
session_start();
if (isset($_POST['Acciones']) && $_POST['Acciones'] === 'IniciarSesion') {
    include_once '../Model/Sesiones.php';

    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];

    $sesionModel = new Sesiones();
    $valido = $sesionModel->validarUsuario($usuario, $contrasena);

    if ($valido) {
        $_SESSION['usuario'] = $usuario;
        $_SESSION['contrasena']=$contrasena;
        header('Location: ../vistaPrincipal.php');
        exit();
    } else {
        echo "Credenciales inválidas. Vuelve a intentarlo.";
    }
} elseif (isset($_POST['Acciones']) && $_POST['Acciones'] === 'CerrarSesion') {
    session_destroy();
    header('Location: ../blog.html');
    exit();
}
?>

