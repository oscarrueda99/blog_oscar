<?php
require_once '../Model/Paciente.php';


$gestorPaciente = new Pacientes();

$elegirAcciones = isset($_POST['Acciones']) ? $_POST['Acciones'] : "Intentar";

if ($elegirAcciones == 'Crear Paciente') {
    $gestorPaciente->agregarPaciente(
        $_POST['PacIdentificacion'],
        $_POST['PacNombres'],
        $_POST['PacApellidos'],
        $_POST['PacFechaNacimiento'],
        $_POST['PacSexo']
    );
} elseif ($elegirAcciones == 'Actualizar Paciente') {
    $gestorPaciente->actualizarPaciente(
        $_POST['PacIdentificacion'],
        $_POST['PacNombres'],
        $_POST['PacApellidos'],
        $_POST['PacFechaNacimiento'],
        $_POST['PacSexo'],
        $_POST['PacEstado']
    );
} elseif ($elegirAcciones == 'Borrar Paciente') {
    $gestorPaciente->borrarPaciente($_POST['PacIdentificacion'],null,null, null, null,'Inactivo');

} elseif ($elegirAcciones == 'Buscar Pacientes') {
    $resultado = $gestorPaciente->consultarPaciente($_POST['PacIdentificacion']);
} 
$resultado = $gestorPaciente->consultarPacientes();
include "../View/vistaPaciente.php";
?>
