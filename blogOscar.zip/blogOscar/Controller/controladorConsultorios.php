<?php
require_once '../Model/Consultorios.php';


$gestorConsultorios = new Consultorios();

$elegirAcciones = isset($_POST['Acciones']) ? $_POST['Acciones'] : "Intentar";

if ($elegirAcciones == 'Crear Consultorio') {
    $gestorConsultorios->agregarConsultorio(
        $_POST['ConNumero'],
        $_POST['ConNombre']
    );
} elseif ($elegirAcciones == 'Actualizar Consultorio') {
    $gestorConsultorios->actualizarConsultorio(
        $_POST['ConNumero'],
        $_POST['ConNombre']
    );
} elseif ($elegirAcciones == 'Borrar Consultorio') {
    $gestorConsultorios->borrarConsultorio($_POST['ConNumero']);
} elseif ($elegirAcciones == 'Buscar Consultorio') {
    $resultado = $gestorConsultorios->consultarConsultorio($_POST['ConNumero']);
}

$resultado = $gestorConsultorios->consultarConsultorios();
include "../View/vistaConsultorios.php";
?>
