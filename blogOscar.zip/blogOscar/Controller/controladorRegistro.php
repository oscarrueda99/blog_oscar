<?php
require_once '../Model/Paciente.php';

$gestorPaciente = new Pacientes();

$elegirAcciones = isset($_POST['Acciones']) ? $_POST['Acciones'] : "Intentar";

if ($elegirAcciones == 'Crear Paciente') {
    $gestorPaciente->agregarPaciente(
        $_POST['PacIdentificacion'],
        $_POST['PacNombres'],
        $_POST['PacApellidos'],
        $_POST['PacFechaNacimiento'],
        $_POST['PacSexo']
    );
    header('Location: ../blog.html');
}
?>