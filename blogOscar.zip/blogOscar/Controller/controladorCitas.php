<?php
require_once '../Model/Citas.php';

$gestorCitas = new Citas();

$elegirAcciones = isset($_POST['Acciones']) ? $_POST['Acciones'] : "Intentar";

if ($elegirAcciones == 'Crear Cita') {
    $gestorCitas->agregarCita(
        $_POST['CitNumero'],
        $_POST['CitFecha'],
        $_POST['CitHora'],
        $_POST['CitPaciente'],
        $_POST['CitMedico'],
        $_POST['CitConsultorio'],
        $_POST['CitEstado']
    );
} elseif ($elegirAcciones == 'Actualizar Cita') {
    $gestorCitas->actualizarCita(
        $_POST['CitNumero'],
        $_POST['CitEstado']
    );
} elseif ($elegirAcciones == 'Borrar Cita') {
    $gestorCitas->borrarCitas($_POST['CitNumero']);
} elseif ($elegirAcciones == 'Buscar Cita') {
    $resultado = $gestorCitas->consultarCita($_POST['CitNumero']);
}

$resultado = $gestorCitas->consultarCitas();
include "../View/vistaCitas.php";
?>
