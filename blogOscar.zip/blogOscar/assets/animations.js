// Animación de desplazamiento suave para anclas
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Ejemplo de animación de cambio de color en el footer
const footer = document.querySelector('.footer');
footer.addEventListener('mouseover', () => {
    footer.style.backgroundColor = '#2c3e50';
});
footer.addEventListener('mouseout', () => {
    footer.style.backgroundColor = '#3498db';
});

// Animación de aparición gradual para las secciones
const sections = document.querySelectorAll('section');
window.addEventListener('scroll', () => {
    sections.forEach(section => {
        const top = window.scrollY;
        const offset = section.offsetTop;
        const height = section.offsetHeight;

        if (top >= offset && top < offset + height) {
            section.style.opacity = '1';
            section.style.transform = 'translateX(0)';
        } else {
            section.style.opacity = '0';
            section.style.transform = 'translateX(-100px)';
        }
    });
});