<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="assets/style.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="blog.html">Volver al blog</a>
        </div>
    </nav>
    <div class="container mt-5">
        <h1 class="mb-3">Iniciar Sesión</h1>
        <hr>
        <div class="login-container">
            <form action="Controller/controladorSesiones.php" method="post">
                <div class="card p-3">
                    <div class="mb-3">
                        <label for="usuario" class="form-label">Usuario</label>
                        <input class="form-control" id="usuario" name="usuario" type="text" required>
                    </div>
                    <div class="mb-3">
                        <label for="contrasena" class="form-label">Contraseña</label>
                        <input class="form-control" id="contrasena" name="contrasena" type="password" required>
                    </div>
                    <button onclick="alert('Inicio Sesión');" class="btn btn-primary" type="submit" name="Acciones" value="IniciarSesion">Iniciar Sesión</button>
                </div>
            </form>
        </div>
    </div>
    <br>
    <footer class="footer">
        <div class="container">
            <p>&copy; 2023 Blog de Psicología</p>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


