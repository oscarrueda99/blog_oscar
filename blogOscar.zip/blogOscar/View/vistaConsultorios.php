<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultorios</title>
    <link rel="stylesheet" href="assets/style.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="../blog.html">Volver al blog</a>
        </div>
    </nav>
    <div class="container mt-5">
        <h1 class="mb-3">Consultorios</h1>
        <a class="btn btn-secondary" href="../vistaPrincipal.php">Volver al menú principal</a>
        <hr>
        <h3>Lista de Consultorios</h3>
        <form action="../Controller/controladorConsultorios.php" method="post">
            <button class="btn btn-primary mb-3" type="submit" name="Acciones" value="Refrescar tabla">Refrescar tabla</button>
        </form>
        <div class="table-responsive mt-3">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Numero de Consultorio</th>
                        <th>Nombre de Consultorio</th>
                        <th>Actualizar</th>
                    </tr>
                </thead>
                <tbody>
            <?php
            while ($fila = mysqli_fetch_assoc($resultado)) {
                echo "<tr>";
                echo "<td>" . $fila['ConNumero'] . "</td>";
                echo "<td>" . $fila['ConNombre'] . "</td>";
                echo '<td>
                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#updateModal' . $fila['ConNumero'] . '">Actualizar</button>
                      </td>';
                echo "</tr>";
                echo '<div class="modal fade" id="updateModal' . $fila['ConNumero'] . '" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">';
                echo '<div class="modal-dialog">';
                echo '<div class="modal-content">';
                echo '<div class="modal-header">';
                echo '<h5 class="modal-title" id="updateModalLabel">Actualizar Consultorio - Número: ' . $fila['ConNumero'] . '</h5>';
                echo '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>';
                echo '</div>';
                echo '<div class="modal-body">';
                echo '<form action="../Controller/controladorConsultorios.php" method="post">';
                echo '<input type="hidden" name="ConNumero" value="' . $fila['ConNumero'] . '">';
                echo '<div class="mb-3">
                        <label class="form-label">Nuevo nombre de Consultorio</label>
                        <input class="form-control" name="ConNombre" type="text">
                      </div>';
                echo '<button class="btn btn-warning" type="submit" name="Acciones" value="Actualizar Consultorio">Actualizar Consultorio</button>';
                echo '</form>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
            ?>
        </tbody>
            </table>
        <hr>
        <div>
            <h3>Agregar</h3>
            <form action="../Controller/controladorConsultorios.php" method="post">
                <div class="mb-3">
                    <label for="ConNumeroAgregar" class="form-label">Número de Consultorio</label>
                    <input class="form-control" id="ConNumeroAgregar" name="ConNumero" type="number">
                </div>
                <div class="mb-3">
                    <label for="ConNombreAgregar" class="form-label">Nombre de Consultorio</label>
                    <input class="form-control" id="ConNombreAgregar" name="ConNombre" type="text">
                </div>
                <button class="btn btn-success" type="submit" name="Acciones" value="Crear Consultorio">Crear Consultorio</button>
            </form>
        <hr>
            <h3>Borrar</h3>
            <form action="../Controller/controladorConsultorios.php" method="post">
                <div class="mb-3">
                    <label for="ConNumeroBorrar" class="form-label">Número de Consultorio a borrar</label>
                    <input class="form-control" id="ConNumeroBorrar" name="ConNumero" type="number">
                </div>
                <button class="btn btn-danger" type="submit" name="Acciones" value="Borrar Consultorio">Borrar Consultorio</button>
            </form>
        </div>
        <hr>
        </div>
    </div>
    <br><br>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
