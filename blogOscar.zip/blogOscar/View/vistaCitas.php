<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Citas</title>
    <link rel="stylesheet" href="assets/style.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="../blog.html">Volver al blog</a>
        </div>
    </nav>
    <div class="container mt-5">
        <h1 class="mb-3">Citas</h1>
        <a class="btn btn-secondary" href="../vistaPrincipal.php">Volver al menú principal</a>
        <hr>
        <div>
        <h3>Lista de Citas</h3>
        <form action="../Controller/controladorCitas.php" method="post">
            <button class="btn btn-primary mb-3" type="submit" name="Acciones" value="Refrescar tabla">Refrescar tabla</button>
        </form>
        <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#crearCitaModal">Crear Cita</button>
        <div class="modal fade" id="crearCitaModal" tabindex="-1" aria-labelledby="crearCitaModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="crearCitaModalLabel">Crear Nueva Cita</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="../Controller/controladorCitas.php" method="post">
                            <div class="mb-3">
                                <label for="CitNumero" class="form-label">Número de Cita</label>
                                <input class="form-control" id="CitNumero" name="CitNumero" type="number">
                            </div>
                            <div class="mb-3">
                                <label for="CitFecha" class="form-label">Fecha</label>
                                <input class="form-control" id="CitFecha" name="CitFecha" type="date">
                            </div>
                            <div class="mb-3">
                                <label for="CitHora" class="form-label">Hora</label>
                                <input class="form-control" id="CitHora" name="CitHora" type="time">
                            </div>
                            <div class="mb-3">
                                <label for="CitPaciente" class="form-label">Paciente</label>
                                <input class="form-control" id="CitPaciente" name="CitPaciente" type="text">
                            </div>
                            <div class="mb-3">
                                <label for="CitMedico" class="form-label">Médico</label>
                                <input class="form-control" id="CitMedico" name="CitMedico" type="text">
                            </div>
                            <div class="mb-3">
                                <label for="CitConsultorio" class="form-label">Consultorio</label>
                                <input class="form-control" id="CitConsultorio" name="CitConsultorio" type="number">
                            </div>
                            <div class="mb-3">
                                <label for="CitEstado" class="form-label">Estado</label>
                                <select class="form-select" id="CitEstado" name="CitEstado">
                                    <option value="Asignada">Asignada</option>
                                    <option value="Cumplida">Cumplida</option>
                                    <option value="Solicitada">Solicitada</option>
                                    <option value="Cancelada">Cancelada</option>
                                </select>
                            </div>
                            <button class="btn btn-success" type="submit" name="Acciones" value="Crear Cita">Crear Cita</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="table-responsive mt-3">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Numero de Cita</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Paciente</th>
                        <th>Médico</th>
                        <th>Consultorio</th>
                        <th>Estado</th>
                        <th>Actualizar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($fila = mysqli_fetch_assoc($resultado)) {
                        echo "<tr>";
                        echo "<td>" . $fila['CitNumero'] . "</td>";
                        echo "<td>" . $fila['CitFecha'] . "</td>";
                        echo "<td>" . $fila['CitHora'] . "</td>";
                        echo "<td>" . $fila['CitPaciente'] . "</td>";
                        echo "<td>" . $fila['CitMedico'] . "</td>";
                        echo "<td>" . $fila['CitConsultorio'] . "</td>";
                        echo "<td>" . $fila['CitEstado'] . "</td>";
                        echo '<td>
                                <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#updateModal' . $fila['CitNumero'] . '">Actualizar</button>
                            </td>';
                        echo "</tr>";
                        echo '<div class="modal fade" id="updateModal' . $fila['CitNumero'] . '" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">';
                        echo '<div class="modal-dialog">';
                        echo '<div class="modal-content">';
                        echo '<div class="modal-header">';
                        echo '<h5 class="modal-title" id="updateModalLabel">Actualizar Cita - Número: ' . $fila['CitNumero'] . '</h5>';
                        echo '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>';
                        echo '</div>';
                        echo '<div class="modal-body">';
                        echo '<form action="../Controller/controladorCitas.php" method="post">';
                        echo '<input type="hidden" name="CitNumero" value="' . $fila['CitNumero'] . '">';
                        echo '<div class="mb-3">
                                <label class="form-label">Estado</label>
                                <select class="form-select" name="CitEstado">
                                    <option value="Asignada">Asignada</option>
                                    <option value="Cumplida">Cumplida</option>
                                    <option value="Solicitada">Solicitada</option>
                                    <option value="Cancelada">Cancelada</option>
                                </select>
                            </div>';
                        echo '<button class="btn btn-warning" type="submit" name="Acciones" value="Actualizar Cita">Actualizar Cita</button>';
                        echo '</form>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <hr>
        <h3>Borrar</h3>
        <form action="../Controller/controladorCitas.php" method="post">
            <div class="mb-3">
                <label for="CitNumeroBorrar" class="form-label">Cita a borrar</label>
                <input class="form-control" id="CitNumeroBorrar" name="CitNumero" type="number">
            </div>
            <button class="btn btn-danger" type="submit" name="Acciones" value="Borrar Cita">Borrar Cita</button>
        </form>
        </div>
        <hr>
    </div>
    <br><br>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
