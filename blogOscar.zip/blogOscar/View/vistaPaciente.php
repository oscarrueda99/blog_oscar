<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paciente</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="../blog.html">Volver al blog</a>
        </div>
    </nav>
    <div class="container mt-5">
        <h1 class="mb-3">Pacientes</h1>
        <a class="btn btn-secondary mb-3" href="../vistaPrincipal.php">Volver menú principal</a>
        <hr>
        <h3>Lista de Pacientes</h3>
        <form action="../Controller/controladorPaciente.php" method="post" class="mb-3">
            <button class="btn btn-primary" type="submit" name="Acciones" value="Refrescar tabla">Refrescar tabla</button>
        </form>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Identificación Paciente</th>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Fecha de Nacimiento</th>
                        <th>Sexo</th>
                        <th>Estado</th>
                        <th>Editar</th>
                        <th>Borrar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($fila = mysqli_fetch_assoc($resultado)) {
                        echo "<tr>";
                        echo "<td>" . $fila['PacIdentificacion'] . "</td>";
                        echo "<td>" . $fila['PacNombres'] . "</td>";
                        echo "<td>" . $fila['PacApellidos'] . "</td>";
                        echo "<td>" . $fila['PacFechaNacimiento'] . "</td>";
                        echo "<td>" . $fila['PacSexo'] . "</td>";
                        echo "<td>" . $fila['PacEstado'] . "</td>";
                        echo '<td>
                            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#updateModal' . $fila['PacIdentificacion'] . '">Editar</button>
                        </td>';
                        echo '<td>
                            <form action="../Controller/controladorPaciente.php" method="post">
                                <input type="hidden" name="PacIdentificacion" value="' . $fila['PacIdentificacion'] . '">
                                <button class="btn btn-danger" type="submit" name="Acciones" value="Borrar Paciente">Borrar</button>
                            </form>
                        </td>';
                        echo "</tr>";
                        echo '<div class="modal fade" id="updateModal' . $fila['PacIdentificacion'] . '" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">';
                        echo '<div class="modal-dialog">';
                        echo '<div class="modal-content">';
                        echo '<div class="modal-header">';
                        echo '<h5 class="modal-title" id="updateModalLabel">Actualizar Paciente - ID: ' . $fila['PacIdentificacion'] . '</h5>';
                        echo '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>';
                        echo '</div>';
                        echo '<div class="modal-body">';
                        echo '<form action="../Controller/controladorPaciente.php" method="post">';
                        echo '<input type="hidden" name="PacIdentificacion" value="' . $fila['PacIdentificacion'] . '">';
                        echo '<div class="mb-3">
                            <label class="form-label">Nombres</label>
                            <input class="form-control" name="PacNombres" type="text">
                        </div>';
                        echo '<div class="mb-3">
                            <label class="form-label">Apellidos</label>
                            <input class="form-control" name="PacApellidos" type="text">
                        </div>';
                        echo '<div class="mb-3">
                            <label class="form-label">Fecha de Nacimiento</label>
                            <input class="form-control" name="PacFechaNacimiento" type="date">
                        </div>';
                        echo '<div class="mb-3">
                            <label class="form-label">Sexo</label>
                            <select class="form-select" name="PacSexo">
                                <option value="F">Femenino</option>
                                <option value="M">Masculino</option>
                            </select>
                        </div>';
                        echo '<div class="mb-3">
                            <label class="form-label">Estado</label>
                            <select class="form-select" name="PacEstado">
                                <option value="Activo">Activo</option>
                                <option value="Inactivo">Inactivo</option>
                            </select>
                        </div>';
                        echo '<button class="btn btn-warning" type="submit" name="Acciones" value="Actualizar Paciente">Actualizar Paciente</button>';
                        echo '</form>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <hr>
        <div>
            <h3>Agregar</h3>
            <form action="../Controller/controladorPaciente.php" method="post">
                <div class="mb-3">
                    <label class="form-label">Identificación Paciente</label>
                    <input class="form-control" name="PacIdentificacion" type="text">
                </div>
                <div class="mb-3">
                    <label class="form-label">Nombres</label>
                    <input class="form-control" name="PacNombres" type="text">
                </div>
                <div class="mb-3">
                    <label class="form-label">Apellidos</label>
                    <input class="form-control" name="PacApellidos" type="text">
                </div>
                <div class="mb-3">
                    <label class="form-label">Fecha de Nacimiento</label>
                    <input class="form-control" name="PacFechaNacimiento" type="date">
                </div>
                <div class="mb-3">
                    <label class="form-label">Sexo</label>
                    <select class="form-select" name="PacSexo">
                        <option value="F">Femenino</option>
                        <option value="M">Masculino</option>
                    </select>
                </div>
                <button class="btn btn-success" type="submit" name="Acciones" value="Crear Paciente">Crear Paciente</button>
            </form>
        </div>
    </div>
    <br><br>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
