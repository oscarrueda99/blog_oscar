<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Citas Médicas</title>
    <link rel="stylesheet" href="assets/style.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">Sistema de Citas Médicas</a>
        </div>
    </nav>
    <div class="container mt-4">
        <h1 class="text-center mb-4">Sistema de Citas Médicas</h1>
        <div class="row">
            <div class="col-md-6">
                <div class="card menu-item">
                    <div class="card-body text-center">
                        <h3 class="menu-title">Médicos</h3>
                        <a href="Controller/controladorMedico.php" class="btn btn-primary btn-block menu-button">Ir</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card menu-item">
                    <div class="card-body text-center">
                        <h3 class="menu-title">Pacientes</h3>
                        <a href="Controller/controladorPaciente.php" class="btn btn-primary btn-block menu-button">Ir</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card menu-item">
                    <div class="card-body text-center">
                        <h3 class="menu-title">Consultorios</h3>
                        <a href="Controller/controladorConsultorios.php" class="btn btn-primary btn-block menu-button">Ir</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card menu-item">
                    <div class="card-body text-center">
                        <h3 class="menu-title">Citas</h3>
                        <a href="Controller/controladorCitas.php" class="btn btn-primary btn-block menu-button">Ir</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center mt-4">
            <form action="Controller/controladorSesiones.php" method="post">
                <button onclick="alert('Cerró Sesión');" class="btn btn-danger" type="submit" name="Acciones" value="CerrarSesion">Cerrar sesión</button>
            </form>
        </div>
    </div>
    <footer class="footer mt-4">
        <div class="container">
            <p>&copy; 2023 Blog de Psicología</p>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
