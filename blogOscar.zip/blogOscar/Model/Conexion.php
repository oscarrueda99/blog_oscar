<?php
function Conectarse(){
	$Conexion =  mysqli_connect("localhost","root","","citas","3306");
	return $Conexion;
}
?>