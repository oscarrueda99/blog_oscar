<?php
include 'Conexion.php';
class Pacientes
{
    private $PacIdentificacion;
    private $PacNombres;
    private $PacApellidos;
    private $PacFechaNacimiento;
    private $PacSexo;
    private $PacEstado;
    private $Conexion;

    public function __construct($PacIdentificacion = null, $PacNombres = null, $PacApellidos = null, $PacFechaNacimiento = null, $PacSexo = null)
    {
        $this->PacIdentificacion = $PacIdentificacion;
        $this->PacNombres = $PacNombres;
        $this->PacApellidos = $PacApellidos;
        $this->PacFechaNacimiento = $PacFechaNacimiento;
        $this->PacSexo = $PacSexo;
        $this->Conexion = Conectarse();
    }

    public function agregarPaciente($PacIdentificacion = null, $PacNombres = null, $PacApellidos = null, $PacFechaNacimiento = null, $PacSexo = null)
    {
        $this->Conexion = Conectarse();

        $sql = "INSERT INTO pacientes(PacIdentificacion, PacNombres, PacApellidos, PacFechaNacimiento, PacSexo)
        VALUES ('$PacIdentificacion','$PacNombres','$PacApellidos','$PacFechaNacimiento','$PacSexo')";
        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        return $resultado;
    }

    public function consultarPaciente($PacIdentificacion)
    {
        $this->Conexion = Conectarse();

        $sql = "SELECT * FROM Pacientes WHERE PacIdentificacion ='$PacIdentificacion'";
        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        
        return $resultado;
    }

    public function consultarPacientes()
    {
        $this->Conexion = Conectarse();

        $sql = "SELECT * FROM Pacientes";
        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        return $resultado;
    }

public function borrarPaciente($PacIdentificacion, $PacNombres, $PacApellidos, $PacFechaNacimiento, $PacSexo, $PacEstado)
{
    $this->Conexion = Conectarse();

    $sql = "UPDATE pacientes SET PacEstado = 'Inactivo' WHERE PacIdentificacion=?";
        
    $stmt = $this->Conexion->prepare($sql);
    $stmt->bind_param("s", $PacIdentificacion);

    $resultado = $stmt->execute();

    $stmt->close();
    $this->Conexion->close();

    return $resultado;
}

    public function actualizarPaciente($PacIdentificacion, $PacNombres, $PacApellidos, $PacFechaNacimiento, $PacSexo, $PacEstado)
    {
        $this->Conexion = Conectarse();
    
        $sql = "UPDATE pacientes SET PacNombres=?, PacApellidos=?, PacFechaNacimiento=?, PacSexo=? , PacEstado=? WHERE PacIdentificacion=?";
            
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("ssssss", $PacNombres, $PacApellidos, $PacFechaNacimiento, $PacSexo,$PacEstado, $PacIdentificacion);
    
        $resultado = $stmt->execute();
    
        $stmt->close();
        $this->Conexion->close();
    
        return $resultado;
    }
}