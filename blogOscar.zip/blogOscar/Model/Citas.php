<?php
include 'Conexion.php';
class Citas
{
    private $CitNumero;
    private $CitFecha;
    private $CitHora;
    private $CitPaciente;
    private $CitMedico;
    private $CitConsultorio;
    private $CitEstado;
    private $Conexion;

    public function __construct(
        $CitNumero = null,
        $CitFecha = null,
        $CitHora = null,
        $CitPaciente = null,
        $CitMedico = null,
        $CitConsultorio = null,
        $CitEstado = null
    ) {
        $this->CitNumero = $CitNumero;
        $this->CitFecha = $CitFecha;
        $this->CitHora = $CitHora;
        $this->CitPaciente = $CitPaciente;
        $this->CitMedico = $CitMedico;
        $this->CitConsultorio = $CitConsultorio;
        $this->CitEstado = $CitEstado;

        $this->Conexion = Conectarse();
    }

    public function agregarCita(
        $CitNumero = null,
        $CitFecha = null,
        $CitHora = null,
        $CitPaciente = null,
        $CitMedico = null,
        $CitConsultorio = null,
        $CitEstado = null
    ) {
        $this->Conexion = Conectarse();

        $sql = "INSERT INTO citas(CitNumero, CitFecha,CitHora,CitPaciente,CitMedico,CitConsultorio,CitEstado)
        VALUES ('$CitNumero','$CitFecha','$CitHora','$CitPaciente',
        '$CitMedico','$CitConsultorio','$CitEstado')";

        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        return $resultado;
    }
    public function consultarCita($CitNumero)
    {
        $this->Conexion = Conectarse();

        $sql = "SELECT * FROM citas WHERE  CitNumero ='$CitNumero'";
        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        return $resultado;
    }
    public function consultarCitas()
    {
        $this->Conexion = Conectarse();

        $sql = "SELECT * FROM citas";
        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        return $resultado;
    }
    public function borrarCitas($CitNumero)
    {
        $this->Conexion = Conectarse();

        $sql = "DELETE FROM citas WHERE CitNumero = '$CitNumero'";
        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        return $resultado;
    }
    public function actualizarCita($CitNumero, $CitEstado)
    {
        $this->Conexion = Conectarse();
    
        $sql = "UPDATE citas SET CitEstado=? WHERE CitNumero=?";
        
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("ss", $CitEstado, $CitNumero);

        $resultado = $stmt->execute();

        $stmt->close();
        $this->Conexion->close();
        return $resultado;
    }  
}