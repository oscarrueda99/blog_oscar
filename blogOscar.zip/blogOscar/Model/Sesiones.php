<?php
include 'Conexion.php'; 
class Sesiones
{
    private $conexion;

    public function __construct()
    {
        $this->conexion = Conectarse();
    }
    public function validarUsuario($usuario, $contrasena)
    {
        $consulta = "SELECT * FROM usuarios WHERE usuario = ? AND contrasena = ?";
        $stmt = $this->conexion->prepare($consulta);
        $stmt->bind_param("ss", $usuario, $contrasena);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $stmt->close();
        return $resultado->num_rows > 0;
    }
}
?>