<?php
include 'Conexion.php';
class Consultorios
{
    private $ConNumero;
    private $ConNombre;
    private $Conexion;

    public function __construct($ConNumero = null, $ConNombre = null)
    {
        $this->ConNumero = $ConNumero;
        $this->ConNombre = $ConNombre;
        $this->Conexion = Conectarse();
    }
    public function agregarConsultorio($ConNumero = null, $ConNombre = null)
    {
        $this->Conexion = Conectarse();

        $sql = "INSERT INTO consultorios(ConNumero, ConNombre)
        VALUES ('$ConNumero','$ConNombre')";
        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        return $resultado;
    }
    public function consultarConsultorio($ConNumero)
    {
        $this->Conexion = Conectarse();

        $sql = "SELECT * FROM consultorios WHERE  ConNumero ='$ConNumero'";
        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        return $resultado;
    }
    public function consultarConsultorios()
    {
        $this->Conexion = Conectarse();

        $sql = "SELECT * FROM consultorios";
        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        return $resultado;
    }
    public function borrarConsultorio($ConNumero)
    {
        $this->Conexion = Conectarse();

        $sql = "DELETE FROM consultorios WHERE ConNumero = '$ConNumero'";
        $resultado = $this->Conexion->query($sql);
        $this->Conexion->close();
        return $resultado;
    }
    public function actualizarConsultorio($ConNumero, $ConNombre)
    {
        $this->Conexion = Conectarse();
    
        $sql = "UPDATE consultorios SET ConNombre=? WHERE ConNumero=?";
        
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("ss", $ConNombre, $ConNumero);

        $resultado = $stmt->execute();

        $stmt->close();
        $this->Conexion->close();
        return $resultado;
    }
}