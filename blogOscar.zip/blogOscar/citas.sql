CREATE DATABASE citas;
USE citas;

CREATE TABLE Consultorios(
    ConNumero int(3) not null,
    ConNombre varchar (50) not null,
    primary key (ConNumero)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE Medicos(
    MedIdentificacion char(10) not null,
    MedNombres varchar(50) not null,
    MedApellidos varchar(50) not null,
    MedEstado enum ('Activo','Inactivo') not null DEFAULT 'Activo',
    primary key (MedIdentificacion)
)ENGINE=InnoDB DEFAULT CHARSET=latin1; 

CREATE TABLE Pacientes(
    PacIdentificacion char(10) not null,
    PacNombres varchar(50) not null,
    PacApellidos varchar(50) not null,
    PacFechaNacimiento date not null,
    PacSexo enum ('M','F','N','O','P') not null,
    PacEstado enum ('Activo','Inactivo') not null DEFAULT 'Activo',
    primary key (PacIdentificacion)
)ENGINE=InnoDB DEFAULT CHARSET=latin1; 

CREATE TABLE citas(
    CitNumero int(11) not null AUTO_INCREMENT,
    CitFecha date not null,
    CitHora varchar (10) not null,
    CitPaciente char(10) not null,
    CitMedico char(10) not null,
    CitConsultorio int(3) not null,
    CitEstado enum ('Asignada','Cumplida','Solicitada','Cancelada') not null DEFAULT'Asignada',
    primary key (`CitNumero`),key CitPaciente(`CitPaciente`), key `CitMedico`(`CitMedico`),key `CitConsultorio`(`CitConsultorio`),
    CONSTRAINT `citas_ibfk_1` FOREIGN KEY(CitPaciente) REFERENCES Pacientes(PacIdentificacion),
    CONSTRAINT `citas_ibfk_2`FOREIGN KEY (CitMedico) REFERENCES Medicos (MedIdentificacion),
    CONSTRAINT `citas_ibfk_3` FOREIGN KEY (CitConsultorio) REFERENCES Consultorios(ConNumero)
)ENGINE=InnoDB DEFAULT CHARSET=latin1; 

ALTER TABLE `citas` ADD UNIQUE(`CitHora`);

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL,
    contrasena VARCHAR(255) NOT NULL
);

INSERT INTO `usuarios` (`id`, `usuario`, `contrasena`) VALUES 
(NULL, 'Admin', 'admin1');

INSERT INTO Consultorios (ConNumero, ConNombre) VALUES
    (1, 'Consultorio A'),
    (2, 'Consultorio B'),
    (3, 'Consultorio C');

INSERT INTO Medicos (MedIdentificacion, MedNombres, MedApellidos, MedEstado) VALUES
    ('m1', 'Juan', 'Pérez', 'Activo'),
    ('m2', 'María', 'González', 'Activo'),
    ('m3', 'Carlos', 'Rodríguez', 'Inactivo');

INSERT INTO Pacientes (PacIdentificacion, PacNombres, PacApellidos, PacFechaNacimiento, PacEstado) VALUES
    ('12345', 'Luis', 'Martínez', '1990-05-15', 'Activo'),
    ('23456', 'Ana', 'López', '1985-09-20', 'Activo'),
    ('34567', 'Pedro', 'Ramírez', '2001-02-10', 'Inactivo');
    
INSERT INTO citas (CitFecha, CitHora, CitPaciente, CitMedico, CitConsultorio, CitEstado) VALUES
    ('2023-08-15', '10:00 AM', '12345', 'm1', 1, 'Asignada'),
    ('2023-08-15', '11:30 AM', '23456', 'm2', 2, 'Cumplida'),
    ('2023-08-16', '03:15 PM', '34567', 'm3', 3, 'Solicitada');