<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <link rel="stylesheet" href="assets/style.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="blog.html">Volver al blog</a>
        </div>
    </nav>
    <div class="container mt-5">
        <h1 class="mb-3">Registrarse</h1>
        <hr>
        <div>
            <form action="Controller/controladorRegistro.php" method="post">
                <div class="mb-3">
                    <label for="PacIdentificacion" class="form-label">Identificación(C.C o T.I)</label>
                    <input class="form-control" id="PacIdentificacion" name="PacIdentificacion" type="text">
                </div>
                <div class="mb-3">
                    <label for="PacNombres" class="form-label">Nombres</label>
                    <input class="form-control" id="PacNombres" name="PacNombres" type="text">
                </div>
                <div class="mb-3">
                    <label for="PacApellidos" class="form-label">Apellidos</label>
                    <input class="form-control" id="PacApellidos" name="PacApellidos" type="text">
                </div>
                <div class="mb-3">
                    <label for="PacFechaNacimiento" class="form-label">Fecha de Nacimiento</label>
                    <input class="form-control" id="PacFechaNacimiento" name="PacFechaNacimiento" type="date">
                </div>
                <div class="mb-3">
                    <label for="PacSexo" class="form-label">Sexo</label>
                    <select class="form-select" id="PacSexo" name="PacSexo">
                        <option value="F">Femenino</option>
                        <option value="M">Masculino</option>
                        <option value="N">No binario</option>
                        <option value="O">Otro</option>
                        <option value="P">Prefiero no Decirlo</option>
                    </select>
                </div>
                <button class="btn btn-success mb-3" type="submit" name="Acciones" value="Crear Paciente">Registar</button>
            </form>
        </div>
    </div>
    <footer class="footer">
        <div class="container">
            <p>&copy; 2023 Blog de Psicología</p>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
